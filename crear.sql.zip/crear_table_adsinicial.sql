
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `adsinicial`
--

CREATE TABLE `adsinicial` (
  `id` int(11) NOT NULL,
  `ruta` varchar(250) NOT NULL,
  `descripcion` varchar(250) NOT NULL,
  `titulo` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `adsinicial`
--

INSERT INTO `adsinicial` (`id`, `ruta`, `descripcion`, `titulo`) VALUES
(4, 'imagenes/demo3_885x450.jpg', '', ''),
(5, 'imagenes/demo1_885x450.jpg', '', '');
