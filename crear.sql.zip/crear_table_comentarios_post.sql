
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `comentarios_post`
--

CREATE TABLE `comentarios_post` (
  `id_comentario` int(11) NOT NULL,
  `post_id` int(11) NOT NULL,
  `usuario_comentario` varchar(100) NOT NULL,
  `email_usuario_comentario` varchar(100) NOT NULL,
  `comentario` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `comentarios_post`
--

INSERT INTO `comentarios_post` (`id_comentario`, `post_id`, `usuario_comentario`, `email_usuario_comentario`, `comentario`) VALUES
(5, 1, 'Juana yepez', 'juana@gmail.com', 'Juana es un libro'),
(2, 1, 'Kevin yepes', 'Kevinadg@gmail.com', 'Segundo comentario de prueba'),
(3, 1, 'vanessa hoyos', 'vanesa@gmail.com', 'Esto es otro comentario'),
(4, 1, 'Gloria yepes', 'gloria@gmail.com', 'comentario # 3 comentario # 3comentario # 3comentario # 3'),
(6, 1, 'isabella ibarra', 'isa@gmail.com', 'libro muy largo 500 paginas'),
(7, 1, 'isabella ibarra', 'isa@gmail.com', 'libro muy largo 500 paginas'),
(8, 1, 'camilo andres ibarra yepes', 'camilo.ibarray@gmail.com', 'La novela narra la historia de Gibreel Farishta y Saladin Chamcha, dos actores de origen indio. Farishta es una estrella de Bollywood especializado en papeles religiosos con un fuerte complejo de superioridad; Chamcha, un emigrante que ha roto con su pasada identidad hindÃº, trabaja como actor de voz para comerciales, experto en adoptar cualquier acento, lo que le ha ganado la fama del "Hombre de las Mil Voces".'),
(9, 2, 'Juana Ibarra', 'juana@gmail.com', 'La novela narra la historia de Gibreel Farishta y Saladin Chamcha, dos actores de origen indio. Farishta es una estrella de Bollywood especializado en papeles religiosos con un fuerte complejo de superioridad; Chamcha, un emigrante que ha roto con su pasada identidad hindÃº, trabaja como actor de voz para comerciales, experto en adoptar cualquier acento, lo que le ha ganado la fama del "Hombre de las Mil Voces".'),
(10, 2, 'Kevin yepes', 'Kevinadg@gmail.com', 'La secuencia de Jahilia es la que contiene mÃ¡s elementos considerados como blasfemos por los musulmanes. En esta parte somos partÃ­cipes de la vida de Mahoma (Mahound en el libro), su exilio y su eventual regreso triunfante a La Meca preislÃ¡mica y politeÃ­sta (Jahilia en la novela).\r\n\r\nEn esta visiÃ³n es donde se hace alusiÃ³n a los versos satÃ¡nicos: Abu Simbel, lÃ­der de Jahilia y esposo de Hind, sacerdotisa de la diosa Al-Lat, le ofrece a Mahound un pacto: Ã©l admitirÃ¡ a tan sÃ³lo tres de las diosas de Jahilia, como arcÃ¡ngeles de AlÃ¡, y le permitirÃ¡ al pueblo su adoraciÃ³n y Abu Simbel (y por consiguiente, el pueblo) aceptarÃ¡ a AlÃ¡. Mahound atribulado sube al monte Cone, a pedirle una revelaciÃ³n al ArcÃ¡ngel Gabriel, obligÃ¡ndole inconscientemente a dictarle unos versos en los que se proclame la validez de las tres deidades.'),
(12, 1, 'isaisas', '', 'Tras un enfrentamiento con Hind, y al darse cuenta de la trampa en la que habÃ­a caÃ­do (puesto que incluso su gente empezaba a dudar de las supuestas revelaciones) Mahound vuelve a subir al monte Cone para enfrentarse fÃ­sicamente con el arcÃ¡ngel, sÃ³lo para ser vencido. Con esto, Mahound se convence a sÃ­ mismo de que ahora sÃ­ es el verdadero arcÃ¡ngel, puesto que un humano nunca podrÃ­a vencer al mensajero de Dios. Vuelve a recibir los versos ahora proclamando la existencia de solo un Dios y nadie mÃ¡s, y que los versos que anteriormente le dictara el supuesto arcÃ¡ngel en realidad habÃ­an sido dictados por SatÃ¡n. Sin embargo, ambos dictados, admite Farishta, no han provenido de Ã©l, sino del interior del profeta, convirtiendo al arcÃ¡ngel en un mero tÃ­tere cantando glosolalia.\r\n\r\nPero es quizÃ¡s la visiÃ³n del ImÃ¡n, un lÃ­der religioso, la que le valiÃ³ la fatwa emitida por el AyatolÃ¡ Jomeini, Ã©l mismo un lÃ­der religioso exiliado en ParÃ­s. Durante la visiÃ³n se retrata al imÃ¡n como una figura de pesadilla que manipula al arcÃ¡ngel Gabriel a travÃ©s de la fuerza y la violencia, para respaldar sus acciones, igual de violentas, para con su pueblo.'),
(13, 7, 'camilo andres ibarra yepes', 'camilo.ibarray@gmail.com', 'hola'),
(14, 1, 'camilo andres ibarra yepes', 'camilo.ibarray@gmail.com', 'ESTE COMENTARIO ES CON CSS'),
(15, 2, 'hola', 'si', 'aaaaaaa');
