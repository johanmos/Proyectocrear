
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `menu_header`
--

CREATE TABLE `menu_header` (
  `id` int(100) NOT NULL,
  `titulo` varchar(250) NOT NULL,
  `url` varchar(250) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `menu_header`
--

INSERT INTO `menu_header` (`id`, `titulo`, `url`) VALUES
(10, 'NUEVAS OFERTAS', ''),
(9, 'CONTACTO', ''),
(8, 'CATEGORIAS', ''),
(11, 'BLOG', ''),
(12, 'PEDIDOS', ''),
(13, 'OFERTAS IRRESISTIBLES', '');
