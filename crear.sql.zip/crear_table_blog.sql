
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `blog`
--

CREATE TABLE `blog` (
  `id` int(11) NOT NULL,
  `titulo` varchar(100) NOT NULL,
  `contenido` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `blog`
--

INSERT INTO `blog` (`id`, `titulo`, `contenido`) VALUES
(1, '', ''),
(2, 'camilo', 'ontenido'),
(3, 'Entrada 2', 'El proceso se continuÃ³, guardando relaciÃ³n con el tema de la evaluaciÃ³n formativa, de esta manera a continuaciÃ³n se presenta el resultado de los artÃ­culos mÃ¡s relevantes y su cercanÃ­a con el tema tratado, se podrÃ¡ observar que artÃ­culos presentan desarrollo propio, que actores involucra (padre, profesor, alumno) y para terminar y concluir se podrÃ¡ notar los resultados de que artÃ­culos y/o desarrollos encontrados refuerzan la evaluaciÃ³n formativa en el aula');
