
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `categorias`
--

CREATE TABLE `categorias` (
  `id` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `time_up` timestamp NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `categorias`
--

INSERT INTO `categorias` (`id`, `name`, `time_up`) VALUES
(1, 'boligrafo', '0000-00-00 00:00:00'),
(7, 'Ejecutivo', '0000-00-00 00:00:00'),
(8, 'botones', '0000-00-00 00:00:00'),
(9, 'Confeccion', '0000-00-00 00:00:00'),
(10, 'Agendas', '0000-00-00 00:00:00'),
(11, 'Cuadernos', '0000-00-00 00:00:00'),
(12, 'Zapatos', '0000-00-00 00:00:00'),
(13, 'Medias', '1970-01-01 05:00:00'),
(28, 'computadores', '2016-12-07 00:05:41');
